﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class DoctorHasWorkScheduleNotOnContrary : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_WorkSchedules_Doctors_Id",
                schema: "Telemetry",
                table: "WorkSchedules");

            migrationBuilder.AddForeignKey(
                name: "FK_Doctors_WorkSchedules_Id",
                schema: "Telemetry",
                table: "Doctors",
                column: "Id",
                principalSchema: "Telemetry",
                principalTable: "WorkSchedules",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Doctors_WorkSchedules_Id",
                schema: "Telemetry",
                table: "Doctors");

            migrationBuilder.AddForeignKey(
                name: "FK_WorkSchedules_Doctors_Id",
                schema: "Telemetry",
                table: "WorkSchedules",
                column: "Id",
                principalSchema: "Telemetry",
                principalTable: "Doctors",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
